package com.example.tipcalculator

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performTextInput
import com.example.tipcalculator.ui.theme.TipCalculatorTheme
import org.junit.Rule
import org.junit.Test

class TipUITests {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun calculate_20_percent_tip() {
        composeTestRule.setContent {
            TipCalculatorTheme {
                TipCalculatorApp()
            }
        }

        // Mengetikkan jumlah tagihan
        composeTestRule.onNodeWithText("Jumlah Tagihan (Rp)")
            .performTextInput("100000")

        // Mengetikkan persentase tip
        composeTestRule.onNodeWithText("Persentase Tip (%)")
            .performTextInput("20")

        // Memastikan UI menampilkan hasil yang benar
        composeTestRule.onNodeWithText("Jumlah Tip: Rp20.000,00").assertExists()
    }
}