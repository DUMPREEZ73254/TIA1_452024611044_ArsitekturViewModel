package com.example.tipcalculator

import org.junit.Assert.assertEquals
import org.junit.Test

class TipCalculatorTests {

    @Test
    fun calculateTip_20PercentNoRoundUp() {
        val amount = 100000.0
        val tipPercent = 20.0
        val expectedTip = "Rp20.000,00" // Sesuaikan format output string lokalmu

        val actualTip = calculateTip(amount, tipPercent)

        assertEquals(expectedTip, actualTip)
    }

    // SKENARIO UJI BUATAN SENDIRI (Di luar codelab)
    @Test
    fun calculateTip_ZeroAmountAndTip() {
        val amount = 0.0
        val tipPercent = 0.0
        val expectedTip = "Rp0,00"

        val actualTip = calculateTip(amount, tipPercent)

        assertEquals(expectedTip, actualTip)
    }
}